#!/usr/local/bin/perl -w
use strict;

use IO::File;

## PatMatch
## Copyright (C) 2004 The Arabidopsis Informatin Resource
##
## This program is free software; you can redistribute it and/or
## modify it under the terms of the GNU General Public License
## as published by the Free Software Foundation; either version 2
## of the License, or (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


## Program to test nrgrep_coords indirectly through scan_pipeline, which is the
## output of PatMatch.


# Parameters used for testing
my $SEQ_FILE = "ATH1_cdna_test.prepared"; # dataset used for testing

# UTILITY METHODS #############################################################

# Extract gene model name from result header string
sub extractGeneModelName {
    my $header = shift;
    $header =~ s/>//g; # remove '>'
    $header =~ s/:/ /g; # replace ':' with spaces
    $header =~ s/\[//g; # remove '['
    $header =~ s/\]//g; # remove ']'
    $header =~ s/,/ /g; # replace ',' with spaces
    my ($name, $start, $end) = split(/ /, $header);
    return $name;
}

# Get file handle of the search results
sub getResultsFileHandle {
    my $residueType = shift;
    my $pattern = shift;
    my $mismatch = shift;
    my $mismatchTypes = shift;

    my $search = IO::File->new("perl ../scan_pipeline.pl '$residueType' '$pattern' '$SEQ_FILE' '$mismatch' '$mismatchTypes' |");
    return $search;
}

sub compareResults {
    my $expected = shift;
    my $actual = shift;
    if ($expected eq $actual) {
	return "";
    } else {
	return "Expected $expected, got $actual";
    }
}

sub testWithOneResult {
    my $residueType = shift;
    my $pattern = shift;
    my $mismatch = shift;
    my $mismatchTypes = shift;
    my $expectedResult = shift;
    my $testCaseName = shift;

    my $search = getResultsFileHandle($residueType, $pattern, $mismatch,
				      $mismatchTypes);
    my $count = 0;
    my $compareError = "";
    while (defined(my $line = $search->getline())) {
	if ($line =~ m/^>/) {
	    $count++;
	    chomp($line);
	    my $geneName = extractGeneModelName($line);
	    $compareError = compareResults($expectedResult, $geneName);
	}
    }
    if (($count != 1) || (! $compareError eq "")) {
	print "ERROR: $testCaseName\n";
	if ($count != 1) {
	    print "$count results returned when one was expected\n";
	}
	if (! $compareError eq "") {
	    print "$compareError\n";
	}
    }
    $search->close();
}

# NR-GREP TEST CASES ##########################################################

sub testBeginAnchor {
    # Upper case
    testWithOneResult("-n", "<ATG", 0, "ids", "At1g01020.1", 
		      "testBeginAnchor/upperCase");
    # Lower case
    testWithOneResult("-n", "<AAA", 0, "ids", "At1g01010.1",
		      "testBeginAnchor/lowerCase");
}

sub testEndAnchor {
    # Upper case
    testWithOneResult("-n", "TAG>", 0, "ids", "At1g01020.1",
		      "testEndAnchor/upperCase");
    # Loser case
    testWithOneResult("-n", "AAG>", 0, "ids", "At1g01010.1",
		      "testEndAnchor/lowerCase");
}

sub testPatternLargerThanSequence {
    # This pattern is larger than the pattern for At1g01040.1 which is 'ctt'
    testWithOneResult("-n", "CTTCATA", 0, "ids", "At1g01030.1",
		      "testPatternLargerThanSequence");
}

sub testHitInFastaHeader {
    # FASTA headers should not be searched
    my $search = getResultsFileHandle("-n", "family", 0, "ids");
    my $count = 0;
    while (defined(my $line = $search->getline())) {
	$count++;
    }
    if ($count > 0) {
	print "ERROR: testHitInFastaHeader\n";
    }
    $search->close();
}

sub testPatternRepetition {
    # Searching for the 'gagagaga'
    my $search = getResultsFileHandle("-n", "(ga){4}", 0, "ids");
    my $count = 0;
    while (defined(my $line = $search->getline())) {
	if ($line =~ m/^>/) {
	    $count++;
	}
    }
    if ($count != 2) {
	print "ERROR: testPatternRepititon\n";
	print "Expected 2 hits but got $count\n";
    }
    $search->close();
}

sub testMatchEntireSequence {
    # 'ctt' constitutes the entire sequence of At1g01040.1 in the sample
    # dataset.
    my $search = getResultsFileHandle("-n", "ctt", 0, "ids");
    my $found = 'f';
    while (defined(my $line = $search->getline())) {
	if ($line =~ m/^>/) {
	    chomp($line);
	    my $geneName = extractGeneModelName($line);
	    if ($geneName eq "At1g01040.1") {
		$found = 't';
	    }
	}
    }
    if ($found eq 'f') { # did not find the hit in At1g01040.1
	print "ERROR: testMatchEntireSequence\n";
	print "Hit in At1g01040.1 not found.\n";
    }
}

sub testCaseInsensitivity {
    # The pattern 'gtgaaaatg' occurs in At1g01010.1 and spans both lower and
    # upper case in the sequence in the dataset.  It doesn't occur anywhere
    # else in the dataset.
    testWithOneResult("-n", "gtgaaaatg", 0, "ids", "At1g01010.1", 
		      "testCaseInsensitivity");
}

# TESTING #####################################################################

# A method to test the utility methods in this program
sub testUtils {
    # Test model name extractor
    my $name = extractGeneModelName(">YBL018C:[130,133]");
    compareResults("YBL018C", $name);
    $name = extractGeneModelName(">At1g01010.1:[195,197]");
    compareResults("At1g01010.1", $name);

    # Test results file handle
    my $search = getResultsFileHandle("-n", "<ATG", 0, "ids");
    while (defined(my $line = $search->getline())) {
	if ($line =~ m/^>/) { 
	    chomp($line);
	    my $geneName = extractGeneModelName($line);
	    my $err = compareResults("At1g01020.1", $geneName);
	    if (! $err eq "") {
		print "$err\n";
	    }
	}
    }
    $search->close();
    
    print "Utility tests complete.\n";
}

###############################################################################

sub main {
    testUtils();
    testBeginAnchor();
    testEndAnchor();
    testPatternLargerThanSequence();
    testHitInFastaHeader();
    testPatternRepetition();
    testMatchEntireSequence();
    testCaseInsensitivity();
    print "NR-grep tests complete.\n";
}

main();
