#!/usr/bin/env python
"""A little wrapper around nrgrep_coords for unit testing."""

import popen2
import unittest
import threading
import re


class ScanPipeline:
    def __init__(self):
        pass


    def search(self, query, inputString):
        child_stdout, child_stdin = popen2.popen2(
            ["nrgrep_coords/nrgrep_coords", query])
        t = threading.Thread(target=self.write_input,
                             args=(child_stdin, inputString,))
        t.setDaemon(True)
        t.start()
        return self.grab_coords(child_stdout.read())


    def write_input(self, stdin, inputString):
        stdin.write(inputString)
        stdin.close()


    def grab_coords(self, output):
        """Returns a list of 2-tuple byte offsets as half-open
        intervals."""
        coord_strings = re.findall(r"\[(\d+), (\d+)\]", output)
        return [(int(x), int(y)) for (x, y) in coord_strings]



class ScanPipelineTests(unittest.TestCase):
    def setUp(self):
        self.p = ScanPipeline()

    def testSearch(self):
        simpleText = """alphabeta"""        
        self.assertEquals([(0, 1), (4, 5), (8, 9)],
                          self.p.search("a", simpleText))


    def testBeginAnchoring(self):
        text = """
this shouldn't match
should this match?
yes, but this should not.
""".strip()
        self.assertEquals([(21, 27)],
                          self.p.search("^should", text))
        self.assertEquals([(5, 11), (21, 27), (54, 60)],
                          self.p.search("should", text))


    def testEndAnchoring(self):
        text = """
this shouldn't match
should this match?
yes, but this should not.
""".strip()
        self.assertEquals([(15, 20)],
                          self.p.search("match$", text))
        self.assertEquals([],
                          self.p.search("should$", text))


    def testMismatchAtEnd(self):
        text = """
MASSSSTLPLHMYIRPLIIEDLKQILNLESQGFPPNERASEEIISFRLINCPELCSGLFIREIEGKEVKKETLIGHIMGTKIPHEYITIESMGKLQVESSNHIGIHSVVIKPEYQKKNLATLLLTDYIQKLSNQEIGNKIVLIAHEPLIPFYERVGFKIIAENTNVAKDKNFAEQKWIDMERELIKEEYDN
""".strip()
        self.assertEquals([],
                          self.p.search("((YD...)(YD...)(YD...)*)", text))

    def testLongerPattern(self):
        text = """
MEECPICLADDQEGEQFGCLNVCGHKFHLNCIREWHKYSINLKCPICRVESTHLEVGEGQHALSINLKMGFMIKNAIDYVGAETTNERNEDDTGEQDQEIEFLSERLRGTLVMDTIKIIQCSICGDTDVSRLSLYCQDCEAIYHETCLRGLACEVGDRNTWQECTDCRSNALLELRMGAISSQLASYDSRNSMIFAGELRDKHSVKTQQMYEQIRNAKHKIQMHVRRALDRYPLPLLRFKDAYKHVNKQVSRKLYRLSDNKYLPDQYDYDSLARTGVHTELLIYCHDE
""".strip()
        self.assertEquals([(3, 31)],
                          self.p.search("CPICLADDQEGEQFGCLNVCGHKFHLNC", text))

if __name__ == '__main__':
    unittest.main()
